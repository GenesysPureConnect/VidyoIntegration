function toggle(div_id) {
	var el = document.getElementById(div_id);
	if ( el.style.display == 'none' ) {	el.style.display = 'block';}
	else {el.style.display = 'none';}
}

// configuration of behavior for this code
var useConsoleForLogging = false;
var useAlertsForLogging = false;
var useCallbackForOutEvents = true;		// if false, use a JavaScript event instead of callback
var willStartOnLoad = true;			// if true, will invoke start() on plug-in object from bodyLoaded()

// Toggle Icon code
var img_camera_array= new Array('resources/images/vidyo/camera_privacy.png','resources/images/vidyo/camera.png');
var img_mic_array= new Array('resources/images/vidyo/mic_mute.png','resources/images/vidyo/mic.png');
var img_speaker_array= new Array('resources/images/vidyo/speaker_mute.png','resources/images/vidyo/speaker.png');
var count_camera=-1;
var count_mic=-1;
var count_speaker=-1;
var userName;
var isSharing = false;

function updateShareList() {
	log('updateShareList()');
    var request = {
    		'type': "RequestGetWindowsAndDesktops"
	};
    var msg;
    if (plugin().sendRequest(request)) {
        msg = "VidyoWeb sent " + request.type + " request successfully";
    } else {
        msg = "VidyoWeb did not send " + request.type + " request successfully!";
    }
    log("clientDesktopsAndWindowsGet(): " + msg, request);

    var transformedData = {
        windows: [],
        desktops: [],
//        sharing: (self.currentShareId === undefined) ? false : true
    };
    var i,
        name,
        mywindow,
        desktop;
    for (i = 0; i < request.numApplicationWindows; i++) {
        name = (request.appWindowAppName[i] && request.appWindowAppName[i].length) ? request.appWindowAppName[i] : request.appWindowName[i];
        if (name.toLowerCase().indexOf("outlook") == -1) {
	        mywindow = {
	            id: request.appWindowId[i],
	            name: name,
	//            highlight: (self.currentShareId === request.appWindowId[i]) ? true : false
	        };
	        transformedData.windows.push(mywindow);
        }
    }
    
    var options = $("#img_share_b");
	options.html('');
	options.append($("<option style='display:none'/>"));
	
	if (isSharing) {
		options.append($("<option/>").val(-1).text("Arr�ter le partage"));
	}
	
    $.each(transformedData.windows, function() {
        options.append($("<option/>").val(this.id).text(this.name));
    });
}

function shareChanged(shareId) {    
    //shareId = -1 means stop sharing
    if (shareId == -1) {
    	stopSharing();
    } else {
    	startSharing(shareId);
    }
}

function startSharing(shareId) {
	isSharing = true;   

	log("sending share event with id " + shareId);

    sendShareEvent(shareId);
}

function stopSharing() {
	isSharing = false;
	log("sending unshare event");
	sendUnshareEvent();
}

/**
 * Send a group chat message
 * @param  {String} message Message to send.
 * @return {Object} Application object
 */
function sendChatMessage() {
	var message = document.getElementById("chatMessageInput").value;
	document.getElementById("chatMessageInput").value = '';
	
	if (message.length > 0) {
		log("sending message " + message);	
		sendGroupChatEvent(message);		
		uiChatUpdateView({
            uri: "group",
            message: message,
            isGroup: true,
            isOutgoing: true,
            displayName: userName 
        });
	}
};

function uiChatUpdateView(chatEvent) {
	log('uiChatUpdateView(', chatEvent, ')');

	var chatPaneList = $("#chatMessagesList");
	var li = '<li class="chat_entry">(' + (new Date()).toLocaleTimeString() + ') <b>' + chatEvent.displayName + '</b>: ' + chatEvent.message + '</li>';
	chatPaneList.append(li); 
}

function toggleCameraIcon()
{
	count_camera++;
	document.getElementById("img_camera").src=img_camera_array[count_camera];
	if(count_camera==0)
		sendMuteCameraEvent();
	else
		sendUnmuteCameraEvent();
	if(count_camera==img_camera_array.length-1) {
		count_camera=-1;
	}
}

function toggleMicIcon()
{
	count_mic++;
	document.getElementById("img_mic").src=img_mic_array[count_mic];
	if(count_mic==0)
		sendMuteMicEvent();
	else
		sendUnmuteMicEvent();
	if(count_mic==img_mic_array.length-1) {
		count_mic=-1;
	}
}

function toggleSpeakerIcon()
{
	count_speaker++;
	document.getElementById("img_speaker").src=img_speaker_array[count_speaker];
	if(count_speaker==0)
		sendMuteSpeakerEvent();
	else
		sendUnmuteSpeakerEvent();
	if(count_speaker==img_speaker_array.length-1) {
		count_speaker=-1;
	}
}

function toggleFullScreen()
{
	var element = document.getElementById('videoArea');
	log("uiFullscreenSet()::requestFullScreen()");

    // Supports most browsers and their versions.
    var requestMethod = element.requestFullScreen || element.webkitRequestFullscreen || element.mozRequestFullScreen || element.msRequestFullScreen;

    if (requestMethod) { // Native full screen.
        requestMethod.call(element);
    } else if (window.ActiveXObject !== undefined) { // IE fallback.
        try {
            var wscript = new ActiveXObject("WScript.Shell");
            if (wscript !== null) {
                wscript.SendKeys("{F11}");

            }
        } catch (e) {
        	log('uiFullscreenSet() - IE security level prevented going to full screen');
        }

        $(document).trigger("oldmsfullscreenchange");
    }
}

// helper function declarations
var plugin = function () {
	return document.getElementById('pluginObject');
};
var log = function (msg) {
	if (useConsoleForLogging) {
		console.log(msg);
	}
	if (useAlertsForLogging) {
		alert(msg);
	}
}


// declarations for functions, wired to plugin events
var onOutEvent = function (event) {
	event = event || {};
	var msg = "Received out event with type of " + event.type;
	//alert(msg);
	log(msg);
	if(event.type == 'OutEventSignedIn'){
		log("Joining Own Room");
		sendStartMyMeetingEvent();
	} else if (event.type == 'OutEventLogicStarted'){

	} else if (event.type == 'OutEventConferenceActive'){
		toggle('VidyoProgressBar');
		document.getElementById("VidyoMain").className = 'VidyoMainFull';
        setPreferredMode(1);
	} else if (event.type == 'OutEventConferenceEnded'){
		plugin().stop();
		window.location.replace("home");
	} else if (event.type == 'OutEventGroupChat') {
		uiChatUpdateView(event);
	} else if (event.type == 'OutEventJoinProgress') {
		prog_b = document.getElementById("progress_b").style.width;
        p_int_b = parseInt(prog_b);
        p_int_b = p_int_b + 16.6;
        prog_b = p_int_b.toString() + "%";
        document.getElementById("progress_b").style.width = prog_b;
        msg = "Join Progress " + prog_b;
        log(msg);
	} else if (event.type == 'OutEventAddShare'){
        msg = "Share added from URI: " + event.URI;
        log(msg);
        var params;
        clientSharesSetCurrent(event.URI);
        setPreviewMode("Dock");
    } else if (event.type == 'OutEventRemoveShare'){
        var shares = clientSharesSetCurrent();
        var participants = clientGetNumParticipants();
        setPreviewModeonStatusChange(participants, shares); 
    } else if (event.type == 'OutEventParticipantsChanged'){
        var shares = clientSharesGet();
        setPreviewModeonStatusChange(event.participantCount, shares.numApp); 
    }
//	log(event);
//	var name;
//	for (name in event) {
//		log(name + ": " + event[name]);
//	}
};

/**
 * Select remote share to see
 * @param  {Int} currApp ID of share to see
 * @return {Object} Currently available shares
 */
var clientSharesGet = function () {
    var that = {};
    that.type = "RequestGetWindowShares";

    // public properties for created object,
    // initial values of which are potentially passed
    // into this factory function
    that.requestType ="";// params && params.requestType || "";
    that.remoteAppUri = [""];//params && params.remoteAppUri || [""];
    that.remoteAppName = [""];// params && params.remoteAppName || [""];
    that.numApp = 0;// params && params.numApp || 0;
    that.currApp = 0;// params && params.currApp || 0;
    that.eventUri = "";// params && params.eventUri || "";
    that.newApp =  0;//params && params.newApp || 0;
    
    var msg;
    if (plugin().sendRequest(that)) {
        msg = "VidyoWeb sent " + that.type + " request successfully";
    } else {
        msg = "VidyoWeb did not send " + that.type + " request successfully!";
    }
    return that;
};



/**
 * Select remote share to see
 * @param  {String} currApp ID of share to make watch
 * @return {Object} number of current shares
 */
var clientSharesSetCurrent = function (newURI) {
    var request = clientSharesGet();
    var shares = request.numApp;
    if (newURI){
        for (i = 0; i < request.numApp; i++){
            if (request.remoteAppUri[i]==newURI){
                request.newApp = i+1;
                break;
            }
        }
    }else{
        request.newApp = request.numApp;
    }
    request.type = "RequestSetWindowShares";
    request.requestType = "ChangeSharingWindow";

    var msg;

    if (plugin().sendRequest(request)) {
        msg = "VidyoWeb sent " + request.type + " request successfully";
    } else {
        msg = "VidyoWeb did not send " + request.type + " request successfully!";
    }
    return shares;
};

/**
 * Detects if plugin is installed or not
 *
 * @return {Boolean} Application object
 */
vidyoPluginIsInstalled = function() {
	var isFound = false;
	log('vidyoPluginIsInstalled()');
	navigator.plugins.refresh(false);

	/* Try NPAPI approach */
	/*jslint unparam: true*/
	$.each(navigator.mimeTypes, function (i, val) {
		if (val.type === "application/x-vidyoweb-1.0.5.00065") {
			/* Reload page when plugin is detected */
			log('vidyoPluginIsInstalled() -- NPAPI plugin found');
			isFound = true;
			return true;
		}
	});
	/*jslint unparam: false*/

	/* Try IE approach */
	try {
		var control = new ActiveXObject("VidyoInc.VidyoWeb_1.0.5.00065");
		if (control) {
			log('vidyoPluginIsInstalled() -- ActiveX plugin found');
			isFound = true;
		}
	} catch (ignore) {
	}

	if (isFound) {
		return true;
	} else {
		return false;
	}
};


// declarations for functions, wired to lifecycle events
var bodyLoaded = function () {	
	var pluginPresent = vidyoPluginIsInstalled();
	var x=navigator.plugins.length; // store the total no of plugin stored
	if (!pluginPresent){
		log("Plugin Not Installed!");
		toggle('VidyoInstall');
		toggle('VidyoMain');
		while (!vidyoPluginIsInstalled());
	}
	if (willStartOnLoad) {
		start();
		// sendLoginEvent();
		sendGuestLogin();
	}else{
		log("Error Loading!");
	}

	$("#chatMessageInput").keyup(function (e) {
	    if (e.keyCode == 13) {
	    	//Enter key pressed
	    	sendChatMessage();
	    }
	});
};
var pluginLoaded = function () {
	//alert("Plugin loaded!");
	log("Plugin loaded!");
};

// declarations for functions, wired to clicking of page hyperlinks
var start = function ()	{
	var msg;
	if (useCallbackForOutEvents) {
		plugin().useCallbackForOutEvents = true;
		plugin().outEventCallbackObject = this;
		plugin().outEventCallbackMethod = "onOutEvent";
	} else {
		plugin().useCallbackForOutEvents = false;
		if (plugin() && plugin().attachEvent) {
			// used by IE browser
			log("start() will call attachEvent()");
			plugin().attachEvent("onouteventcallback", onOutEvent);
		} else if (plugin() && plugin().addEventListener) {
			// used by non-IE browsers
			log("start() will call addEventListener()");
			plugin().addEventListener("outeventcallback", onOutEvent, false);
		}
	}
	if (plugin().start()) {
		msg = "VidyoWeb started successfully";
	} else {
		msg = "VidyoWeb did not start successfully!";
		alert(msg);
	}
	log(msg);
}
var isStarted = function () {
	var msg;
	if (plugin().isStarted()) {
		msg = "VidyoWeb is started";
	} else {
		msg = "VidyoWeb is not started";
	}
	alert(msg);
	log(msg);
};

var sendLoginEvent = function () {
	var inEvent = {
			'type': "InEventLogin",
			'portalUri': portalUri,
			'userName': "chetan",
			'userPass': "gandhi"
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent login event successfully";
	} else {
		msg = "VidyoWeb not sent login event successfully!";
		alert(msg);
	}
	log(msg);
};

var sendGuestLogin = function () {
	if (!portalUri){
		return 0;
	}
	var portalRes = portalUri.split("\/flex.html\?roomdirect.html");
	portalUri = portalRes[0];
	guestName = guestName.replace("+"," ");
	if (!guestName){
		guestName = "Guest";
	}
	userName = guestName;
	if (roomPin){
		var inEvent = {
				'type': "PrivateInEventVcsoapGuestLink",
				'typeRequest': "GuestLink",
				'requestId': 1234,
				'portalUri': portalUri,
				'roomKey': roomKey,
				'pin': roomPin,
				'guestName': guestName
		};
	}else{
		var inEvent = {
				'type': "PrivateInEventVcsoapGuestLink",
				'typeRequest': "GuestLink",
				'requestId': 1234,
				'portalUri': portalUri,
				'roomKey': roomKey,
				'guestName': guestName
		};
	}
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent guest login event successfully";
	} else {
		msg = "VidyoWeb not sent guest login event successfully!";
		alert(msg);
	}
	log(msg);
};

var sendStartMyMeetingEvent = function () {
	var inEvent = {
			'type': "PrivateInEventStartMyMeeting"
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent start my meeting event successfully";
	} else {
		msg = "VidyoWeb not sent start my meeting event successfully!";
		alert(msg);
	}
	log(msg);
};

var sendLeaveEvent = function () {
	var inEvent = {
			'type': "InEventLeave"
	};
	var msg;
	// Make sure you reduce the size of the VidyoWeb Plugin renderer now, 
	// otherwise you will see artifacts related to OpenGL
	document.getElementById("pluginObject").style.width="1px";
	document.getElementById("pluginObject").style.height="1px";

	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent leave event successfully";
	} else {
		msg = "VidyoWeb not in a call!";
		alert(msg);
	}
	log(msg);
};

var sendMuteCameraEvent = function () {
	var inEvent = {
			'type': "InEventMuteVideo",
			'willMute': true
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent Mute Camera successfully";
	} else {
		msg = "VidyoWeb could not send Mute Camera successfully!";
		alert(msg);
	}
	log(msg);
};

var sendUnmuteCameraEvent = function () {
	var inEvent = {
			'type': "InEventMuteVideo",
			'willMute': false
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent Mute Camera successfully";
	} else {
		msg = "VidyoWeb could not send Mute Camera successfully!";
		alert(msg);
	}
	log(msg);
};

var sendMuteMicEvent = function () {
	var inEvent = {
			'type': "InEventMuteAudioIn",
			'willMute': true
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent Mute Mic successfully";
	} else {
		msg = "VidyoWeb could not send Mute Mic successfully!";
		alert(msg);
	}
	log(msg);
};

var sendUnmuteMicEvent = function () {
	var inEvent = {
			'type': "InEventMuteAudioIn",
			'willMute': false
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent Mute Mic successfully";
	} else {
		msg = "VidyoWeb could not send Mute Mic successfully!";
		alert(msg);
	}
	log(msg);
};

var sendMuteSpeakerEvent = function () {
	var inEvent = {
			'type': "InEventMuteAudioOut",
			'willMute': true
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent Mute Speaker successfully";
	} else {
		msg = "VidyoWeb could not send Speaker Mic successfully!";
		alert(msg);
	}
	log(msg);
};

var sendUnmuteSpeakerEvent = function () {
	var inEvent = {
			'type': "InEventMuteAudioOut",
			'willMute': false
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent Mute Speaker successfully";
	} else {
		msg = "VidyoWeb could not send Mute Speaker successfully!";
		alert(msg);
	}
	log(msg);
};

var sendGroupChatEvent = function (message) {
	var inEvent = {
			'type': "InEventGroupChat",
			'message': message
	};
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent group message successfully";
	} else {
		msg = "VidyoWeb could not send group message successfully!";
		alert(msg);
	}
	log(msg);
};

var sendShareEvent = function(shareId) {
	var inEvent = {
			 'type': 'InEventShare',
			 'window': shareId
     };
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent share event successfully";
	} else {
		msg = "VidyoWeb could not send share event successfully!";
		alert(msg);
	}
	log(msg);
}

var sendUnshareEvent = function() {
	 var inEvent = {
			 'type': 'InEventUnshare'
     };
	var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent unshare event successfully";
	} else {
		msg = "VidyoWeb could not send unshare event successfully!";
		alert(msg);
	}
	log(msg);
}

var stop = function ()	{
	var msg;
	if (plugin().stop()) {
		msg = "VidyoWeb stopped successfully";
	} else {
		msg = "VidyoWeb did not stop successfully!";
		alert(msg);
	}
	log(msg);
};

var setPreviewModeonStatusChange = function(participants, shares){
    if (participants == 2){
        if (shares>0){
            setPreviewMode("Dock");
        }else{
            setPreviewMode("PIP");
        }
    }else if (participants == 1){
        setPreviewMode("None");
    }else{
        setPreviewMode("Dock");
    }
};

/**
 * Get Number of Participants
 */
var clientGetNumParticipants = function () {
    var that = {};
    that.type = "RequestGetNumParticipants";
    that.numParticipants =0;
    
    var msg;
    if (plugin().sendRequest(that)) {
        msg = "VidyoWeb sent " + that.type + " request successfully";
    } else {
        msg = "VidyoWeb did not send " + that.type + " request successfully!";
    }
    return that.numParticipants;
};

var setPreferredMode = function(preferred){
    var inEvent = {
        'type': "InEventLayout" 
    };
    inEvent.numPreferred = preferred;
    
    var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent login event successfully";
	} else {
		msg = "VidyoWeb not sent Preferred Mode event successfully!";
		alert(msg);
	}
	log(msg);
};

var setPreviewMode = function(previewMode){
    var inEvent = {
        'type': "EventPreview"
    };
    inEvent.previewMode = previewMode;
    
    var msg;
	if (plugin().sendEvent(inEvent)) {
		msg = "VidyoWeb sent preview event successfully";
	} else {
		msg = "VidyoWeb not sent Preview  event successfully!";
		alert(msg);
	}
	log(msg);
};

// code to execute immediately
