/**
  * @fileOverview This file defines the module for the VidyoClient parameter objects.
  * @author Vidyo Inc.
  * @version 1.0.5
  */

define(
	function () {
		return {
		}
	}
);
